<?php
# +------------------------------------------------------------------------+
# | Artlantis CMS Solutions                                                |
# +------------------------------------------------------------------------+
# | Sirius - PHP Multi Language File Editor                                |
# | Copyright (c) Artlantis Design Studio 2014. All rights reserved.       |
# | File Version  3.0                                                      |
# | Last modified 03.05.16                                                 |
# | Email         developer@artlantis.net                                  |
# | Developer     http://www.artlantis.net                                 |
# +------------------------------------------------------------------------+

# italian - autoresponder_front.php
?>